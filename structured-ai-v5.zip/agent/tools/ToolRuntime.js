"use strict";

const filesystem = require("./filesystem");
const fileinfo = require("./filesystem/FileMetadataTools");
const plan = require("./planning");
const memory = require("./memory");
const skills = require("./skills");
const search = require("./search");
const processTools = require("./process");
const git = require("./git");
const net = require("./network");
const telemetry = require("../runtime/Telemetry");
const mcp = require("./mcp");
const discussion = require("./discussion");
const ToolContext = require("./ToolContext");

const {
    capResult,
    capTotalSize
} = require("../context/WorkspaceBoundary");


/*
|--------------------------------------------------------------------------
| Tool Implementations
|--------------------------------------------------------------------------
|
| The single place where a tool name maps to executable behaviour. The
| registry in registry/tools.json declares the same names to the model;
| the runtime validates that the two sides agree at startup.
|--------------------------------------------------------------------------
*/

/*
| Modules may export helpers for testing. Only public tool functions,
| which never start with an underscore, become callable tools.
*/

function publicTools(moduleExports) {

    return Object.fromEntries(
        Object.entries(moduleExports).filter(
            ([name, value]) =>
                !name.startsWith("_") &&
                typeof value === "function"
        )
    );
}


const IMPLEMENTATIONS = {
    ...publicTools(filesystem),
    ...publicTools(fileinfo),
    ...publicTools(plan),
    ...publicTools(memory),
    ...publicTools(skills),
    ...publicTools(git),
    ...publicTools(net),
    ...publicTools(mcp),
    ...publicTools(discussion),

    search_start: search.search_start,
    search_get: search.search_get,
    search_list: search.search_list,
    search_stop: search.search_stop,

    terminal_exec: processTools.terminal_exec,
    process_start: processTools.process_start,
    process_read: processTools.process_read,
    process_write: processTools.process_write,
    process_resize: processTools.process_resize,
    process_terminate: processTools.process_terminate,
    process_list: processTools.process_list,

    runtime_stats: telemetry.runtime_stats
};


function executedToolNames() {

    return telemetry.executedToolNames();
}


/*
| A tool is either one this repository implements or one an MCP server
| offered at discovery time. The second kind does not exist until a
| server has answered, which is why the check is a function call rather
| than a lookup in a table built at startup.
*/

function hasTool(name) {

    if (
        Object.prototype.hasOwnProperty.call(
            IMPLEMENTATIONS,
            name
        )
    ) {
        return true;
    }

    return mcp._hasDiscoveredTool(name);
}


function implementedToolNames() {

    return Object.keys(IMPLEMENTATIONS).sort();
}


/*
| The names an agent may actually call right now, which is the static
| catalogue plus whatever the connected MCP servers are offering.
*/

function callableToolNames() {

    return [
        ...Object.keys(IMPLEMENTATIONS),
        ...mcp._discoveredToolNames()
    ].sort();
}


function mcpToolDeclarations(options = {}) {

    let projectId = null;

    try {

        /* delegation frame first, then the run's own project */
        const { effectiveProjectId } = require("../runtime/ProjectOverride");

        projectId = effectiveProjectId() || null;

    } catch {
        /* outside a run the catalogue is unfiltered (legacy) */
    }

    return mcp._manager.toolDeclarations(projectId, options);
}


async function discoverMcpTools(options) {

    return mcp._discover(options);
}


/*
| Tools that still act on the process-wide workspace rather than the calling
| run's project context. They are safe when the run shares the workspace root;
| on a project rooted elsewhere, executing one would silently mis-scope it,
| so the gate below makes that a loud error.
|
| Plan, memory and search stores resolve through persistence/DataRoot to
| the active project's data root (central for registered projects, the
| compatibility .agent root for the synthetic default). runtime_stats
| stays gated: process-wide telemetry has no project data root it could
| honestly claim.
|
| Derived from the modules themselves so a converted tool can never stay
| listed by accident.
*/

const PENDING_PROJECT_AWARENESS =
    new Set([
        "runtime_stats"
    ]);

const CONTEXT_AWARE_OVERRIDE = new Set();


async function executeTool(
    name,
    args,
    context = {}
) {

    if (!hasTool(name)) {

        throw new Error(
            `Tool is not implemented: ${name}`
        );
    }

    /* Identity never travels as a tool argument (rule 9); the run
       context the runtime attaches is the only channel. */
    ToolContext.assertNoIdentityArguments(args);

    const toolContext =
        ToolContext.from(context);

    if (
        toolContext &&
        toolContext.scoped &&
        !toolContext.sharesWorkspaceRoot() &&
        PENDING_PROJECT_AWARENESS.has(name)
    ) {

        throw new Error(
            `Tool "${name}" is process-scoped and cannot run on ` +
            `project "${toolContext.projectId}" rooted outside this process ` +
            "workspace. Use a workspace-rooted project or a project-aware tool."
        );

    }

    const startedAt = Date.now();

    const telemetryFields =

        toolContext
            ? {
                  ...(toolContext.runId
                      ? { run_id: toolContext.runId }
                      : {}),
                  ...(toolContext.projectId
                      ? { project_id: toolContext.projectId }
                      : {}),
                  ...(toolContext.scoped && toolContext.root
                      ? { project_root: toolContext.root }
                      : {})
              }
            : {};

    try {

        /*
        | A tool receives only its declared arguments. The agent that
        | called it is context, passed under a name no schema uses, for
        | the two tools that report which agent acted. The normalized
        | ToolContext rides as the second positional parameter; tools
        | that predate it simply ignore it, which keeps every
        | non-converted tool bit-identical.
        */

        const implementation =
            IMPLEMENTATIONS[name];

        const result =
            implementation
                ? await implementation(
                    {
                        ...(args || {}),

                        _agent: context.agent
                    },
                    toolContext
                )
                : await mcp._executeDiscovered(
                    name,
                    args || {}
                );

        telemetry.record({
            name,
            success: true,
            durationMs: Date.now() - startedAt,
            agent: context.agent,
            ...telemetryFields,
            arguments: args || {}
        });

        return capTotalSize(
            capResult(result)
        );

    } catch (error) {

        telemetry.record({
            name,
            success: false,
            durationMs: Date.now() - startedAt,
            agent: context.agent,
            ...telemetryFields,
            error: error.message,
            arguments: args || {}
        });

        throw error;
    }
}


function shutdown() {

    processTools.shutdownAll();

    void mcp._shutdown();
}


/*
| State that belongs to one run must not leak into the next: a stale
| search session could be fetched by id, and telemetry from a previous
| run would misreport what this one did. Background processes are the
| exception, they are deliberately long lived, so they are reported
| instead of killed.
*/

function startRunScope(runId) {

    /* With a run id (modular mode) only that run's bucket is cleared;
       the legacy call without one resets the process-wide state exactly
       as before, so sequential CLI behavior is unchanged and two
       concurrent modular runs can never wipe each other's sessions or
       counters mid-flight. */

    search.resetSessions(runId);

    telemetry.reset(runId);

    const mcpScope = mcp._startRunScope();

    const running =
        [...processTools._sessions.values()].filter(
            session => session.status === "running"
        );

    return {
        background_processes:
            running.map(
                session => ({
                    process_id: session.id,
                    command: session.command
                })
            ),
        mcp: mcpScope
    };
}


module.exports = {
    executedToolNames,
    executeTool,
    startRunScope,
    hasTool,
    implementedToolNames,
    callableToolNames,
    mcpToolDeclarations,
    discoverMcpTools,
    shutdown,
    telemetry,
    mcp
};
