# قراردادهای ثبت‌شدهٔ Structured AI — EXECUTION_PLAN Phase 1 (گام ۳)

**تاریخ ثبت:** 2026-08-25 · **منبع حقیقت:** کد فعلی + fixtureهای `test/fixtures/` + تست‌های `test/contracts/`

این سند قراردادهای بیرونی و داخلی‌ای را ثبت می‌کند که در تمام فازهای refactor و Multi-Project باید حفظ شوند. هرگونه تغییر عمدی باید ابتدا در همین سند و fixtureها اعمال و سپس در کد پیاده شود.

---

## ۱. سیاست تغییر قرارداد (Additive-Only)

1. **افزودن فیلد جدید** به event payload، پاسخ API یا action envelope **مجاز** است.
2. **ممنوع:** حذف فیلد موجود، تغییر معنای فیلد، تغییر نام event/ابزار/action، تغییر نوع یک فیلد — مگر با migration عمدی و مستند در EXECUTION_PLAN.
3. نام‌گذاری فیلدهای جدید از قرارداد موجود پیروی می‌کند: رویدادها `snake_case` (`run_id`, `turn_id`, `project_id`) و پاسخ‌های JSON وب `camelCase` (`projectId`) — تصمیم 2026-08-25 (پیوست ب EXECUTION_PLAN).
4. تست‌های `test/contracts/` مرز را اعمال می‌کنند؛ شکست آن‌ها یعنی نقض قرارداد، نه «تست قدیمی».

---

## ۲. قرارداد رویدادها (Event Contract)

### envelope

هر رویداد از `agent/lib/events.js` عبور می‌کند و این فیلدها را **همیشه** دارد:

```json
{
  "seq": "number; افزایشی یکنواخت در هر process",
  "type": "string; نام رویداد",
  "at": "epoch ms",
  "run_id": "از context رویداد، مگر override در payload",
  "turn_id": "مانند بالا",
  "scope": "مانند بالا (main_agent یا scopeٔ Sub-Agent)",
  "iteration": "مانند بالا"
}
```

معنای `turn_id` (رسمی‌شده 2026-08-25): هر پیام کاربر در یک session مکالمه‌ای یک turn تازه است؛ قالب `<run_id>_t<N>` یا مقدار تأمین‌شده توسط caller (web server). سلسله‌مراتب پروژه‌ای هدف: `project_id ⊃ run_id ⊃ turn_id ⊃ iteration`.

### فهرست نام‌ها (inventory)

۶۳ نام در `test/fixtures/events.json` قفل شده‌اند. تست اسکن ایستا `test/contracts/events.contract.test.js` هر تغییری در مجموعهٔ نام‌های emitشده را می‌شکند. نام‌های مکانیکی bus (`event`, `change`) بخشی از قرارداد نیستند.

### payloadهای کلیدی

رویدادهای جریان اصلی و فیلدهای مهم فعلی‌شان (افزوده‌پذیر):

| رویداد | فیلدهای مهم فعلی |
|---|---|
| `run:start` | `run_id`, `turn_id`, `task` |
| `agent:iteration` | `iteration` |
| `request:start` / `request:end` | اطلاعات درخواست مدل |
| `agent:response`, `agent:action` | خلاصهٔ پاسخ/اکشن |
| `tool:start` | `id`, `name` |
| `tool:end` | `id`, `name`, `success` |
| `policy:decision`, `approval:request`, `approval:resolved` | چرخهٔ policy/approval |
| `context:compacted`, `context:memory` | مدیریت context |
| `run:nudge` | تکرار درخواست خروجی نهایی معتبر |
| `run:end` | `success` |
| `report:mismatch` | جلوگیری از ادعای تأییدنشده |

 سکانس baseline برای یک اجرای سادهٔ final (دو iteration به‌علت nudge) در `events.json.baseline_final_turn_sequence` قفل شده است.

---

## ۳. قرارداد Action

envelope پاسخ مدل (کلیدهای سطح-یک): `version`(`"1.0"`), `tool_calls`, `delegations`, `response`, `data`, `error`, `action`, `performed`. ورودی parser همان envelope خام provider است: `{ choices: [ { message: { role, content } } ] }`.

فیلدهای الزامی (تأییدشده با اجرای واقعی):

| نوع | فیلدهای الزامی هر آیتم |
|---|---|
| `tool_calls[]` | `id`, `name`, `arguments`, `depends_on` |
| `delegations[]` | `id`, `agent`, `persona`, `skills`, `tools`, `task`, `depends_on` |
| `response` (final) | `type`, `content` |

رفتارهای نرمال‌سازی/خطا (قفل‌شده در `actions.json`):

- `readModelAction` به tool call فاقد `depends_on` مقدار `[]` تزریق می‌کند.
- delegation به agent **ثبت‌شده** باید `persona`/`skills`/`tools` را `null` بگذارد؛ آرایهٔ خالی رد می‌شود.
- متن غیر JSON → پرتاب خطای modelResponseError با پیشوند `AI returned neither structured JSON nor a native tool call.`
- tool call بدون `id` → `Tool call is missing required field(s): id.`
- `parseStructuredResponse` خروجی `{ message, structured, source }` می‌دهد؛ fenceٔ مارک‌داون unwrap می‌شود (`source` متناسب).

---

## ۴. قرارداد Prompt و Request مدل

ساختار پیام‌ها (نقش‌ها و ترتیب بخش‌ها) در `prompt.fixture.json` قفل شده است:

- **Main:** system (متن system_prompt) ← system (EXECUTION RULES) ← system (json `runtime_context`) ← system (`available_skills`) ← system (`available_personas`) ← system (`available_agents`) ← user (task).
- **Sub-Agent:** system (قواعد اجرا) ← `runtime_context` ← `agent_profile` ← `available_tools` ← user(json `task`).
- `runtime_context` این کلیدهای سطح-یک را دارد: `workspace, environment, repository, execution, limits, security, plan, memory, archive, policy, endpoints, runtime, mcp`.

بدنهٔ request به مدل (capture واقعی): کلیدها `messages, model, parallel_tool_calls, response_format, temperature, tools`؛ با `temperature: 0.2`, `parallel_tool_calls: true`, `response_format: { type: "json_schema", json_schema: { name: "agent_action", strict: false, ... } }`. ابزارها در فیلد `tools` (schema کامل) و نه متن تکراری در پیام‌ها ارسال می‌شوند.

*رفتار dynamic که در فازهای بعد باید حفظ شود:* خواندن مجدد `system_prompt.txt`/registry در هر request؛ فیلتر قواعد بر اساس ابزارهای agent؛ کشف ابزارهای MCP پیش از اولین request؛ skill `semantic_engine` فقط هنگام ready بودن؛ settings جدید از iteration بعدی.

---

## ۵. قرارداد API وب

مسیرهای فعلی (literal) در `api-surface.json` ثبت‌اند؛ تست قرارداد، وجود همهٔ آن‌ها و عدم ظهور مسیر مستندنشدهٔ جدید را در `web/server.js` اعمال می‌کند. رفتار اثبات‌شده توسط تست‌های موجود: `POST /api/tasks`, `GET /api/events` (SSE), `GET /api/discussion/personas`, `POST /api/discussion`. ماتریس کامل method × route در فاز ۲۳ (Web Backend refactor) مستند می‌شود؛ در این فاز تغییر پاسخ/کد وضعیت endpointها ممنوع است.

---

## ۶. قراردادهای persistence و CLI

- مسیر state فعلی: `<workspace>/.agent/` (memory, plan, sessions, archive, journal, eventstore, searches, processes و `project.json`). در این فاز تغییر نمی‌کند؛ انتقال به data root مرکزی موضوع فاز ۸ است.
- **مرز دو مفهوم «Project» (رسمی‌شده 2026-08-25 در فاز ۲):**
  - `agent/lib/project.js` («workspace profile»): فایل `.agent/project.json` درون workspace؛ تنظیمات/proفایلِ بازدیدهای قبلیِ همان یک workspace. در نقشهٔ overlay (global ← workspace ← run) می‌ماند و export فعلی‌اش (از جمله `runtime.project`) تغییر نمی‌کند.
  - `agent/projects/` («multi-project registry»): ثبت/resolve چند workspace در فروگاه مرکزی داده (`~/.local/share/structured-ai/registry.json`، با override `STRUCTURED_AI_DATA_HOME`). سطح عمومی از طریق `runtime.projects` عرضه می‌شود.
  - این دو **ادغام نمی‌شوند**؛ مقصد نوشتن تنظیماتِ project-scoped در آیندهٔ فاز ۸ `projects/<id>/project.json` مرکزی است، ولی خواندنِ overlayِ workspace حفظ می‌شود.
- فرمت فایل‌های session/archive/journal/eventstore باید replay-compatible بماند.
- CLI: `node bin/agent.js -w <path> "<task>"` و REPL (`/help`, `/clear`, `/history`, `/approve`, `/tools`, `/save`) حفظ می‌شوند.

## ۷. flagهای migration (قانون ثابت ۸)

flagهای فاز-به-فاز در schema تنظیمات اعلان می‌شوند (نه env خام) تا resolver، UI و snapshot همه یک مقدار را ببینند:

- `PROJECT_CONTEXT_MODE` (پیش‌فرض `legacy`؛ مقدار مجاز دیگر `modular`) — از فاز ۲ موجود است.
- `RUN_CONTEXT_MODE` (پیش‌فرض `legacy`؛ مقدار مجاز دیگر `modular`) — از فاز ۳ موجود است؛ همراه آن `RUN_HISTORY_LIMIT` (NUMBER، پیش‌فرض ۱۰۰) برای ظرفیت تاریخچهٔ Runهای پایان‌یافتهٔ RunManager.
- `PROMPT_BUILDER_MODE` (پیش‌فرض `legacy`) — از فاز ۵.
- `SEMANTIC_POOL_MODE` (پیش‌فرض `legacy`) — از فاز ۶.
- `RUNTIME_ENGINE_MODE` (پیش‌فرض `legacy`؛ مقدار مجاز دیگر `modular`) — از فاز ۱۶؛ هر دو مقدار همان engine استخراج‌شده را اجرا می‌کنند (تصمیم ۳۵). مقدار غلط رفتار legacy دارد.
- `WEB_SERVER_MODE` هنگام ورود به فاز ۲۳ اعلان می‌شود.

## ۸. تغییرات additive فاز ۳ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- رویدادهای emit‌شده **داخل scope یک Run در حالت `RUN_CONTEXT_MODE=modular`** فیلد envelope جدید `project_id` دارند (null وقتی پروژه‌ای resolve نشده). رویدادهای خارج از scope — و بنابراین کل رفتار حالت `legacy` — دقیقاً همان شکل قبلی را دارند؛ fixtureهای فاز ۱ بدون تغییر معتبرند.
- `agent/lib/events.js` یک API جدید additive دارد: `runWithScope(initial, fn)` که context هم‌بستگی را برای یک زنجیرهٔ async ایزوله می‌کند (`setContext` داخل scope به همان scope می‌نویسد). بدون فراخوانی آن، رفتار `emit`/`setContext` بیت‌به‌بیت همان است.
- سطح دسترسی runtime (exports در `agent/agent.js`) additive گسترش یافت: `AgentRunContext`, `runManager`, `runContextMode`, `cancelRunById`. امضاها و رفتار entry pointهای قبلی (`startRun`, `cancelRun`, `isRunCancelled`, `runRemainingMs`, `assertRunActive`, `runAgent`) بدون تغییر؛ در حالت legacy همان state سراسری را هدف می‌گیرند.
- قالب run id حالت modular همان `run-<ISO-timestamp>` است؛ در برخورد هم‌زمان در یک میلی‌ثانیه پسوند `-r<N>` اضافه می‌شود (فقط حالت modular).

## ۹. تغییرات additive فاز ۴ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- امضای سطح ابزار: `executeTool(name, args, context)` بدون تغییر می‌ماند؛ `context` حالا می‌تواند `{ agent, runId, projectId, projectContext }` باشد (همیشه سازگار با شکل قدیمی `{agent}`) و به implementation به‌عنوان **پارامتر دوم** (`implementation(args, toolContext)`) می‌رسد — implementationهای قدیمی آن را نادیده می‌گیرند. schema و نام ابزارها در هیچ حالتی تغییر نمی‌کند.
- rule 9 مکانیکی: آرگومان‌های ابزار نمی‌توانند `projectId`/`project_id`/`project`/`projectRoot`/`root` داشته باشند (خطا)؛ هویت پروژه فقط از مسیر context ران‌تایم می‌رسد.
- `agent/lib/workspace.js` additive گسترش یافت: `resolvePathInRoot`/`assertPathSafeInRoot`/`toRelativeInRoot` و API پروژه‌ای `resolveProjectPath`/`isInsideProject`/`toProjectRelative`/`assertProjectPathSafe`/`projectRootOf`؛ امضای exportهای قبلی پین‌شده به WORKSPACE_ROOT دست‌نخورده.
- telemetry: رکوردها در حالت contextدار حامل `run_id`/`project_id` (additive، فقط در bucket per-run) هستند؛ `executedToolNames(runId?)` و `reset(runId?)` پارامتر اختیاری گرفتند؛ فرم خروجی runtime_stats جهانی تغییر نکرده است.
- sessionهای search با `run_id` علامت‌گذاری می‌شوند و `resetSessions(runId)` فقط همان Run را پاک می‌کند؛ فراخوانی بدون آرگومان رفتار جهانی تاریخی را دارد. sessionهای process دارای `run_id`/`project_id`/`root` هستند و در حالت scoped فقط برای پروژهٔ مالک قابل‌مشاهده/کنترل‌اند.

## ۱۰. تغییرات additive فاز ۵ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- flag `PROMPT_BUILDER_MODE` (پیش‌فرض `legacy`) در schema تنظیمات اعلان شد؛ مسیر modular از builderهای تزریق‌پذیر `agent/prompt/` استفاده می‌کند و خروجی normalized آن با مسیر legacy برابر است (قانون ۸).
- `buildAgentRequest` اکنون از `agent/agent.js` export می‌شود (additive؛ شکل امضا آبجکت واحد `{messages, agentDefinition, tools, responseFormat, role, withSchema}` در هر دو حالت یکسان).
- پیام رویدادنما `project_context` (system+JSON) فقط در اجرای دارای پروژه (modular) به prompt افزوده می‌شود: Main پس از runtime_context و Sub-Agent پس از agent_profile. بدون پروژه هیچ کلید/پیام افزوده‌ای وجود ندارد (شکل prompt تاریخی دست‌نخورده — قانون ۵).
- در اجرای modular با پروژه، فیلدهای `workspace.root` و `runtime.workspace_root` و بخش `repository` پیام runtime_context **root پروژهٔ فعال** را گزارش می‌کنند (در legacy همان WORKSPACE_ROOT فرایند).

## ۱۱. تغییرات additive فاز ۶ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- دو تنظیم schema اعلان شد: `SEMANTIC_POOL_MODE` (پیش‌فرض `legacy`؛ مقدار مجاز دیگر `modular`) برای routing پروژه‌ای Semantic و `SEMANTIC_POOL_CACHE_LIMIT` (NUMBER، پیش‌فرض ۲۰۰، ۰ = غیرفعال) برای سقف cache نتایج per-client.
- `agent/mcp/SemanticClient.js` / `SemanticClientPool.js` / `ProjectSemanticResolver.js` ساخته شدند؛ سطح export ماژول‌های قبلی (`lib/semantic.js`، `mcp/semantic.js`، `mcp/manager.js`، `mcp/client.js`) هیچ تغییری نکرده و در `SEMANTIC_POOL_MODE=legacy` رفتار بیت‌به‌بیت baseline است (تست identity: resolver همان آبجکت ماژول قدیمی را برمی‌گرداند).
- پیاده‌سازی ابزارهای code امضای `(args, context)` گرفت (قرارداد پارامتر دوم فاز ۴)؛ شکل نتایج ابزارها در هر دو حالت یکسان است. در حالت modular ابزار با `projectId`ِ ToolContext از pool client می‌گیرد؛ staleness از root پروژه و sessionهای index per-client است (جست‌وجوی session پروژهٔ دیگر «unknown» برمی‌گرداند).
- خانوادهٔ code از `PENDING_PROJECT_AWARENESS` خارج شد؛ رفتار خطای ریشهٔ خارجی در حالت legacy با همان الگوی «not yet project-aware» در resolver حفظ می‌شود (متن دقیق خطا مکمل است، الگوی اصلی ثابت).
- در حالت modular رویدادهای `mcp:call`/`mcp:result` با نام سرور پروژه‌محور `semantic-engine.project.<id>` منتشر می‌شوند (کلیدها همان envelope فاز ۱ + مقدار متفاوت `server` — افزودنی رفتاری، فقط در حالت pool).
- قراردادی که stub تستی و gateway آینده هر دو سرو می‌کنند: `POST /mcp/:projectId` با `initialize`/`tools/list`/`tools/call` روی Streamable HTTP؛ پاسخ tool در `structuredContent` است و marker افزودنی `{projectId, indexGeneration}` دارد؛ گزارش `indexGeneration` جدید cache سمت client را باطل می‌کند؛ endpoint ناشناخته/پروژه ناشناخته خطای HTTP کنترل‌شده است. تعویض gateway واقعی فقط با ویرایش `semanticEndpoint` در registry + `pool.reload(projectId)` انجام می‌شود.

## ۱۲. تغییرات additive فاز ۷ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- **CLI:** فلگ `--project <id>` به `bin/agent.js` افزوده شد (نه delete/rename؛ گزینه‌های فعلی دست‌نخورده). رفتار اجرایی: root از registry خوانده می‌شود (با `-w` ناسازگار → usage error با پیام «does not match ... registry»؛ بدون `-w` → root ثبت‌شده = WORKSPACE_ROOT)؛ id ناشناخته → `Unknown project: <id>`؛ بدون فلگ هیچ تغییری در env/رفتار نیست. `--project` فلگهای `PROJECT_CONTEXT_MODE`/`RUN_CONTEXT_MODE`/`PROMPT_BUILDER_MODE` را modular می‌کند (بقیهٔ فلگها — از جمله `SEMANTIC_POOL_MODE` — دست‌نخورده).
- **Web API:** مسیر `POST /api/projects/:projectId/tasks` به `web/server.js` اضافه شد: 202 `{accepted:true, project_id}` (فیلد جدید فقط در همین مسیر)؛ 404 `Unknown project`؛ 409 `PROJECT_MODE_REQUIRED` هنگام نبود فلگهای modular؛ 400/409-running عین مسیر قدیمی. قرارداد `POST /api/tasks` بدون هیچ تغییری (202 `{accepted:true}` دقیقاً همان بدنه است — تست deep-equal).
- **امضای داخلی:** `startTask(task, runOptions)` در web/server.js پارامتر اختیاری دوم گرفت (پیش‌فرض `{}`؛ رفتار legacy یکسان)؛ runAgent همان گزینهٔ `{projectId}` فاز ۲ را می‌گیرد.
- **رویدادها:** در اجرای scoped (modular) رویدادهای run فیلدهای envelope موجود `run_id` + `project_id` (additive فاز ۲/۳) را دارند و در `/api/state` (فیلد `events`) بدون تغییر قرارداد دیده می‌شوند.

## ۱۳. تغییرات additive فاز ۸ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- **`agent/lib/dataRoot.js` (ماژول جدید):** resolver واحد مسیر ذخیره‌سازی — `legacyDataRoot`, `modularPersistence`, `fromProject`, `fromContext`, `currentRoot`, `resolveRoot`, `dataRootForProjectId`, `ensureRoot`, `SCAFFOLD_DIRS`. ترتیب resolve: root صریح ← context ← پروژهٔ Run جاری (ALS) ← legacy `.agent/`؛ routing فقط در `PROJECT_CONTEXT_MODE=modular` فعال است (در legacy مسیرها بیت‌به‌بیت baseline).
- **پارامتر root اختیاری در storeها (additive):** `memoryPath/loadMemory/saveMemory`، `planPath/planDirectory` + `loadPlan/savePlan`، `sessionsDirectory/indexPath/sessionPath/loadIndex/saveIndex/loadSession/saveSession/listSessions/deleteSession`، `archiveDirectory/indexPath/segmentPath/loadIndex/saveIndex/appendBody/rollUp/compactSegments/maintain/readBody/findOrphanBody` و `options.root` جدید در `archiveEvents/searchArchive/getRecords/stats`، `storeRoot/fileFor/readDay/listDays` و `root` در `eventstore.query`، `journalRoot/fileFor`. حذف پارامتر = رفتار قبلی (legacy root / ریشهٔ Run جاری).
- **eventstore:** نویسنده با envelope رویداد route می‌کند — `project_id` ثبت‌شده در registry → store مرکزی پروژه؛ synthetic/ناشناخته/legacy → مسیر تاریخی. شکل خط JSONL و نام فایل روز بدون تغییر.
- **journal:** state attribution per `run_id` bucket می‌شود (جداسازی اجراهای هم‌زمان)؛ فیلدهای رکورد (`run_id`, `task`, ...) بدون تغییر شکل؛ export `_state` همان view تاریخی آخرین Run است و `_buckets` (additive) map داخلی را عرضه می‌کند.
- **ابزارها:** `plan_get/plan_set/plan_update` و `memory_get/archive_search/archive_get` پارامتر دوم context (قرارداد فاز ۴) را مصرف می‌کنند — schema و شکل خروجی تغییر نکرده؛ در اجرای scoped خروجی `path` ابزارهای plan/memory ممکن است مسیر **مطلق** مرکزی باشد (به‌جای نسبی درهم) — فیلد موجود، مقدار درست‌تر، فقط در حالت modular. ابزارهای search در اجرای scoped مسیرهای نسبی را نسبت به root پروژه گزارش می‌دهند (در legacy همان workspace-relative تاریخی). group/gate: `PENDING_PROJECT_AWARENESS` حالا فقط `runtime_stats` است؛ متن خطای «not yet project-aware» برای آن حفظ است.
- **overlay تنظیمات (`agent/lib/project.js`):** `openProject(projectId?)` پارامتر اختیاری گرفت؛ exportهای جدید additive: `overlayFor`, `centralProjectPath`, `loadOverlay`؛ پاسخ `openProject` فیلد `overlay_path` را **فقط** وقتی لایهٔ مرکزی هست دارد؛ `persist`/`saveProject` مقصد مرکزی را می‌پذیرند. بدون پروژهٔ modular رفتار بیت‌به‌بیت قبل است (خواندن/نوشتن همان `.agent/project.json`).
- **projects:** سطح `agent/projects` با `ProjectMigration` (`migrateProject(record) → {project_id, source, target, source_present, copied, skipped, errors}`) گسترش یافت — کپی بدون-overwrite، legacy حذف نمی‌شود، خطای per-file در گزارش.
- **CLI:** فلگ `--migrate <id>` افزوده شد (گزینه‌های فعلی دست‌نخورده): root از registry (با `-w` ثبت+مهاجرت یک‌جا)، گزارش روی stderr، exit 1 با خطای فایل، re-run ایدم‌پوتنت (copied=0).

## ۱۴. تغییرات additive فاز ۹ (ثبت‌شده ۲۰۲۶-۰۸-۲۵)

- **Web API (additive):** `GET/POST /api/projects`، `GET/PATCH/DELETE /api/projects/:id`، `GET /api/projects/:id/state`، `GET /api/projects/:id/sessions`، `GET /api/projects/:id/events`، `POST /api/projects/:id/chat`، `POST /api/projects/:id/cancel`. مسیر `POST /api/projects/:id/tasks` فاز ۷ دست‌نخورده است (202 `{accepted, project_id}`). `GET /api/state` و `POST /api/tasks` بدون تغییر قرارداد برای توکن master.
- **Event stream:** `GET /api/events?projectId=` همان فیلتر استریم پروژه‌ای را اعمال می‌کند. رویداد پروژهٔ الف در استریم ب نیست؛ رویداد بدون `project_id` فقط metadata تجمیعی (`aggregate: true`) می‌دهد. توکن master بدون query همهٔ رویدادها را می‌بیند (رفتار قبلی).
- **Token scope:** `AGENT_CONSOLE_TOKEN` همچنان توکن master با همهٔ پروژه‌ها و permissionهاست. `AGENT_CONSOLE_TOKENS` (JSON، secret) توکن‌های محدود `{ allowedProjects, permissions }` را اعلام می‌کند (`project:read`/`project:write`/`semantic:query`/`semantic:index`). دسترسی بدون اجازه → `403`. لاگ‌ها Bearer/token را mask می‌کنند.
- **Approval:** رکورد و رویداد `approval:request`/`approval:resolved` فیلد additive `project_id` دارند؛ prompt ترمینال در صورت وجود پروژه آن را نشان می‌دهد. pendingهای `/api/state` فیلد `project_id` می‌گیرند (UI فعلی نادیده می‌گیرد).
- **MCP scope:** فیلدهای additive `scope: "project"|"global"` (پیش‌فرض `global`) و `projects: [...]` در نرمالایز کانفیگ. `tools/list` و `catalogueEntries(projectId)` فقط سرورهای مجاز آن پروژه را می‌دهند؛ `call` ریشهٔ خارجی را با خطای کنترل‌شده رد می‌کند. در اجرای بدون projectId (legacy) همهٔ سرورها مانند قبل دیده‌ می‌شوند.
- **Gateway MCP approval:** برای سرور `scope: global` در Run دارای `project_id`، یک تأیید کافی است و استفاده‌های بعدی `gateway_cached: true` دارند و با `project_id` مصرف‌کننده audit می‌شوند. بدون `project_id` رفتار approval تاریخی است.

## ۱۵. تغییرات additive فاز ۱۰ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **تنظیمات schema:** `MAX_CONCURRENT_PROJECT_RUNS` (پیش‌فرض ۴)، `MAX_RUNS_PER_PROJECT` (۱)، `MAX_CONCURRENT_INDEX_RUNS` (۲)، `MAX_WORKERS_PER_USER` (۸)، `RUN_QUEUE_LIMIT` (۱۶)، `PROJECT_MEMORY_LIMIT` (۰ = بدون سقف سخت)، `PROJECT_CPU_LIMIT` (۰ = فقط observational).
- **Scheduler:** `agent/runtime/RunScheduler.js` فقط وقتی هر دو flag `RUN_CONTEXT_MODE` و `PROJECT_CONTEXT_MODE` modular باشند و Run یک `projectId` داشته باشد فعال است. overflow صف → خطای `RUN_QUEUE_FULL` با `status=429`. عبور از `PROJECT_MEMORY_LIMIT` → خطای `PROJECT_MEMORY_LIMIT` با `status=429` (صف نمی‌شود).
- **Run id:** `createRun` شناسه را همان لحظه در مجموعهٔ issued رزرو می‌کند تا دو Run هم‌زمان در یک میلی‌ثانیه شناسهٔ یکسان نگیرند (پسوند `-r<N>` مثل فاز ۳).
- **Web API (additive):** `GET /api/metrics`، `GET /api/health`، `GET /api/projects/:id/metrics`، `GET /api/projects/:id/health`. پاسخ `POST /api/projects/:id/cancel` فیلد additive `queued_dropped` دارد. `POST /api/projects/:id/tasks` و `/chat` در overflow صف `429 {code: RUN_QUEUE_FULL}` می‌دهند و در پذیرش فیلد additive `queued` دارند. `POST /api/tasks` بدون تغییر قرارداد است (قفل busy سراسری کنسول حفظ شد).
- **Observability:** سری‌های `project_*` و `gateway_*` از event bus جمع می‌شوند. crash یک پروژه health آن را `down` و gateway را حداکثر `degraded` می‌کند — هرگز `down`.
- **Index:** `code_index_start` سقف `MAX_CONCURRENT_INDEX_RUNS` را با `INDEX_LIMIT` اعمال می‌کند.
- **Exports additive:** `runScheduler` و `observability` از `agent/agent.js`.

## ۱۶. تغییرات additive فاز ۱۱ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **صفحهٔ کنسول:** header `#projectSwitcher` / `#newProjectButton` / `#projectsButton` / `#gatewayHealth` را دارد. انتخاب پروژه در `localStorage` کلید `structured-ai.currentProjectId` و query `?project=` حفظ می‌شود.
- **Static route (additive):** `GET /projects` و `GET /projects/:id` همان `index.html` کنسول را سرو می‌کنند تا deep-link داشبورد کار کند. قرارداد مسیرهای `/api/*` تغییر نکرد.
- **Graph:** `GET /api/graph/*?projectId=` ریشه و نام پروژه را از registry می‌خواند و `project:read` را اعمال می‌کند؛ بدون query همان workspace سرور است.
- **Composer:** radios `current|specific|multiple`. یک هدف → `POST /api/projects/:id/tasks`؛ چند هدف → صف ترتیبی labelدار. `POST /api/tasks` بدون پروژهٔ انتخاب‌شده دست‌نخورده است.
- **Events در UI:** استریم با `?projectId=` دوباره وصل می‌شود؛ رویداد دارای `project_id` ناسازگار وارد نما نمی‌شود؛ رویداد بدون `project_id` همچنان دیده می‌شود (سازگاری legacy).
- **Cancel:** با پروژهٔ فعال، `POST /api/projects/:id/cancel` علاوه بر `POST /api/cancel` صدا زده می‌شود.

## ۱۷. تغییرات additive فاز ۱۲ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **Action `delegate`:** آیتم‌های `delegations[]` فیلد اختیاری additive `projectId` (و alias `project_id`) را می‌پذیرند. نبود/null یعنی پروژهٔ فعال. فیلدهای ناشناخته همچنان رد می‌شوند. در schema غیرسخت `projectId` required نیست؛ در schema سخت (`response_format.strict.json`) با `anyOf: [string, null]` در `required` است.
- **اعمال سوئیچ:** فقط وقتی `PROJECT_CONTEXT_MODE=modular` و `RUN_CONTEXT_MODE=modular`. در legacy فیلد پذیرفته و نادیده گرفته می‌شود (ابزارها همان workspace فرایند را می‌بینند).
- **ایزوله‌سازی Sub-Agent:** `agent/runtime/ProjectOverride.js` با ALS؛ `effectiveProject()` = frame جاری یا پروژهٔ Run. هر فرزند داخل `runWithProject` + `events.withProjectId` اجرا می‌شود تا دو فرزند هم‌زمان `currentRun().project` را mutate نکنند. پروژهٔ یک Sub-Agent در میانهٔ loop عوض نمی‌شود؛ delegation تو در تو با `projectId` متفاوت frame تازه می‌سازد.
- **نتیجهٔ labelدار:** خروجی `executeDelegations` فیلدهای additive `projectId` و `findings` دارد (علاوه بر `id`/`success`/`result`/`agent`/`error`). گزارش موفق Sub-Agent هم `projectId`/`findings` دارد. id ناشناخته فقط همان فرزند را با `Unknown project` شکست می‌دهد.
- **Approval نوشتن:** ابزارهای `fs_write`/`fs_edit`/`fs_mkdir`/`fs_move`/`fs_delete` روی پروژه‌ای غیر از پروژهٔ Run → approval جدا با `rule: "cross_project_write"`؛ هر write پس از delegation به بیش از یک پروژه → `rule: "multi_project_write"`. این approval علاوه بر تصمیم عادی policy است.
- **Events:** `delegation:start`/`delegation:graph`/`delegation:end` فیلد additive `projectId` روی آیتم‌ها دارند. envelope `project_id` رویدادهای scoped فرزند، پروژهٔ همان Sub-Agent است. `policy:decision` فقط وقتی `project_id` دارد که پروژه‌ای واقعاً در scope باشد (مقدار null روی رویداد legacy stamp نمی‌شود).
- **Exports additive:** `effectiveProject`, `effectiveProjectId`, `runWithProject`, `isMultiProjectTask` از `agent/agent.js`؛ `events.withProjectId`.

## ۱۸. پذیرش MVP فاز ۱۳ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** این فاز فیلد/مسیر/action/event تازه‌ای اضافه نمی‌کند. شواهد isolation/load/ده‌مرحله‌ای در `test/mvp/mvp.test.js` (۱۰ تست) قفل شده‌اند و در زنجیرهٔ `npm test` اجرا می‌شوند.
- **باندل runtime رسمی MVP:** `PROJECT_CONTEXT_MODE=modular`، `RUN_CONTEXT_MODE=modular`، `PROMPT_BUILDER_MODE=modular`، `SEMANTIC_POOL_MODE=modular` — فقط وقتی مسیر پروژه‌آگاه فعال است (تست‌ها صریحاً ست می‌کنند؛ CLI `--project` همان bundle سه‌تایی فاز ۷ را ست می‌کند).
- **پیش‌فرض schema:** هر چهار flag بالا پیش‌فرض `legacy` می‌مانند (تصمیم ۳۲). CLI بدون `--project` و `POST /api/tasks` بدون تغییر ظاهری‌اند (بدنهٔ 202 `{accepted:true}` بیت‌به‌بیت).
- **دوام eventstore روی خروج CLI:** `eventstore.flush()` قبل از `process.exit` در `bin/agent.js` و `agent.js#main` صدا زده می‌شود تا صف `appendQueued` با خروج ناگهانی از بین نرود (رفتار persistence فاز ۸؛ شکل فایل JSONL بدون تغییر).

## ۱۹. تغییرات additive فاز ۱۴ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** نام ابزار، schema، event، API و CLI تغییر نکرد. استخراج ساختاری است.
- **Config:** پیاده‌سازی در `agent/config/`؛ `agent/lib/storage.js` wrapper سازگار با همان exportها (`get/set/reset/sourceOf/snapshot/all/describe/definitionOf/definitions/bus`).
- **Registry:** `loadRegistries()` از `RegistryLoader` می‌خواند؛ TOOLS از concat `tool-schemas/` می‌آید. `tools.json` snapshot سازگاری است. JSON خراب → `Registry file <path> is invalid JSON: ...`.
- **Application:** exportهای additive `application`، `registryLoader`، `registryValidator`. `runAgent`/`main` از facade به `application` delegate می‌شوند (همان توابع bound).
- **Live reload:** امضای registry شامل mtime/size فایل‌های `tool-schemas/` است (به‌جای فقط `tools.json`).

## ۲۰. تغییرات additive فاز ۱۵ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** action envelope، نام/کد خطا، `response_diagnostics`، retry malformed و هر دو schema (`response_format.json` / `.strict.json`) دست‌نخورده‌اند. استخراج ساختاری است.
- **Actions:** پیاده‌سازی در `agent/actions/`؛ `agent/agent.js` wrapper سازگار با همان exportها (`parseStructuredResponse`، `adaptNativeToolCalls`، `parseToolArguments`، `repairStructuredAction`، `readModelAction`، `isModelResponseError`، `validateAction`).
- **Export additive:** `actions` از `agent/agent.js` همان kit را برمی‌گرداند. `bind({ toolsOf, events, logLine })` وابستگی زندهٔ registry/bus را تزریق می‌کند.
- **AGENT_SCHEMA:** همچنان `fixed` است (پیش‌فرض `default`)؛ شاخهٔ strict فقط با مقدار startup و فایل `response_format.strict.json` فعال می‌شود.

## ۲۱. تغییرات additive فاز ۱۶ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** نام event، payload منطقی، action envelope، بودجه/عمق delegation، ترتیب wave و `depends_on` دست‌نخورده‌اند. استخراج ساختاری است.
- **Runtime engine:** پیاده‌سازی حلقه در `agent/runtime/{AgentRun,IterationRunner,ActionProcessor,ToolGraphExecutor,DelegationRunner,RetryController,RunState,ReportVerifier}.js`؛ `agent/agent.js` wrapper سازگار با همان exportها (`runAgent`، `callAI`، `executeDependencyGraph`، `executeToolGraph`، `normalizeToolCalls`، `resolveArgumentReferences`، `validateDelegationPolicy`، `resolveDepthBudget`، `checkPerformedClaim`، ...).
- **Export additive:** `runtimeEngine` و `runtimeEngineMode` از `agent/agent.js`. `bind({...})` وابستگی زندهٔ settings/events/run/tools را تزریق می‌کند.
- **Flag:** `RUNTIME_ENGINE_MODE` (پیش‌فرض `legacy`). هر دو مقدار همان engine را اجرا می‌کنند (تصمیم ۳۵)؛ misspell = legacy. پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۲. تغییرات additive فاز ۱۷ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** compaction (light/medium/heavy)، pairing tool call/result، محل memory message، نوشتن archive قبل از drop/fold، `archive_search`/`archive_get`، مسیر data root فاز ۸، و تنظیمات `MAX_CONTEXT_CHARS`/`CONTEXT_*`/`MEMORY_*`/`ARCHIVE_*` دست‌نخورده‌اند. استخراج ساختاری است.
- **Context kit:** پیاده‌سازی در `agent/context/{ContextManager,ConversationSizer,ExchangeDetector,ContextCompactor,MemoryCoordinator,ArchiveCoordinator}.js`؛ IO در `agent/persistence/{MemoryRepository,ArchiveRepository}.js`. `agent/lib/context.js`، `lib/memory.js` و `lib/archive.js` wrapper سازگار با همان exportها هستند.
- **Export additive:** `context` از `agent/agent.js` همان kit را برمی‌گرداند. `bind({ events, logLine, currentRun, assertRunActive, summariseTranscript })` وابستگی زنده را تزریق می‌کند. wrapperهای `maintainContext`/`foldIntoMemory`/`refreshMemoryMessage`/`archiveExchanges` در facade می‌مانند (قانون ۷).
- **Flag:** فاز ۱۷ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۳۶). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۳. تغییرات additive فاز ۱۸ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** مسیر فایل‌ها (فاز ۸ و `.agent/` legacy)، شکل JSON/JSONL، `safeId` session، replay session قدیمی، و skip خط خراب در eventstore/journal دست‌نخورده‌اند. استخراج ساختاری است.
- **Persistence:** پیاده‌سازی در `agent/persistence/{AtomicFile,JsonRepository,SafeIdentifier,SchemaVersion,SessionRepository,JournalRepository,EventStoreRepository}.js`؛ `MemoryRepository`/`ArchiveRepository` JSON را اتمیک می‌نویسند. `agent/lib/sessions.js`، `lib/journal.js` و `lib/eventstore.js` wrapper سازگار با همان exportها هستند.
- **Atomic write:** سند JSON کامل با temp+rename؛ crash قبل از rename فایل قبلی را نگه می‌دارد. JSONL append-only است و خط truncated در خواندن skip می‌شود.
- **Flag:** فاز ۱۸ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۳۷). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۴. تغییرات additive فاز ۱۹ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** نام ابزار، schema، argument validation، امضای `executeTool(name, args, context)`، workspace boundary، process group kill/timeout، semantic fallback، index session، tool result cap و telemetry دست‌نخورده‌اند. استخراج ساختاری است.
- **Tools:** پیاده‌سازی در `agent/tools/{ToolRuntime,ToolRegistryAdapter}` و گروه‌های `filesystem/`، `process/`، `code/`، `planning/`، `memory/`؛ فایل‌های تاریخی `filesystem.js`، `process.js`، `code.js`، `plan.js`، `memory.js`، `fileinfo.js` و `tools/index.js` wrapper سازگار با همان exportها هستند.
- **Export additive:** `ToolRegistryAdapter` از `agent/tools` (parity: registry → schema، runtime → implementation، validator → parity check). `code/SemanticClient.js` همان کلاس `agent/mcp/SemanticClient.js` فاز ۶ است.
- **Flag:** فاز ۱۹ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۳۸). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۵. تغییرات additive فاز ۲۰ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** نام ابزار MCP، namespace `mcp__<server>__<tool>`، handshake چهار transport، framing Content-Length/NDJSON، `mcp_call`، discovery، add/remove runtime، trust/approval، timeout، `MCP_MAX_MESSAGE_BYTES`، و فیلتر `tools/list` فاز ۹ دست‌نخورده‌اند. استخراج ساختاری است.
- **MCP:** پیاده‌سازی در `agent/mcp/{McpManager,McpConfigLoader,McpConfigValidator,McpConnection,McpCatalogue,McpTrustPolicy}.js`، `protocol/{JsonRpcCodec,ContentLengthCodec,NdjsonCodec,McpErrors}.js` و `transports/{Stdio,Http,Sse,WebSocket}Transport.js`. فایل‌های تاریخی `manager.js`/`client.js`/`config.js`/`protocol.js` و `transports/{stdio,http,sse,websocket}.js` wrapper سازگار با همان exportها هستند.
- **Export additive:** `McpConnection` همان کلاس `McpClient` است. `config.serverVisibleTo` به `McpTrustPolicy` delegate می‌شود.
- **Flag:** فاز ۲۰ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۳۹). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۶. تغییرات additive فاز ۲۱ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** policy.json، نام/گروه ابزارها، ترتیب آخرین rule، حالت‌های `auto`/`prompt`/`deny` و پیام‌های خطای policy/approval حفظ شده‌اند؛ استخراج ساختاری است.
- **Policy:** پیاده‌سازی در `agent/policy/{PolicyEngine,PolicyMatcher,PolicyRegistry,PolicyErrors}.js`؛ `PolicyMatcher` روی آرگومان‌های resolveشده match می‌کند و `PolicyEngine` تنها نقطهٔ enforcement/audit است. `agent/lib/policy.js` facade سازگار باقی مانده است.
- **Approval:** `ApprovalManager` lifecycle terminal prompt، handler تزریقی، MCP trust escalation و gateway-level cache را مدیریت می‌کند؛ `ApprovalStore` history و pending recordها را encapsulate می‌کند. `setApprovalHandler`، `getApprovalMode`، `setApprovalMode` و `resetGatewayApprovals` از facade همان exportهای قبلی‌اند.
- **Multi-Project:** pendingها و eventهای `approval:request`/`approval:resolved` فیلد additive `project_id` و filtering per-project فاز ۹ را حفظ می‌کنند؛ approvalهای `cross_project_write`/`multi_project_write` از lifecycle مشترک عبور می‌کنند.
- **Web adapter:** Web Console فقط adapter UI است و pending state را از `ApprovalStore` می‌گیرد؛ `state.approvals` برای سازگاری به‌صورت Map باقی مانده است.
- **Flag:** فاز ۲۱ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۴۰). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۷. تغییرات additive فاز ۲۲ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** `hooks.json`، ترتیب `before_task`/`after_task`، زبان شرط، templateها، `on_failure`، eventهای hook و نتیجهٔ hookها حفظ شده‌اند؛ استخراج ساختاری است.
- **Hooks:** declaration و live reload در `agent/hooks/{HookLoader,HookRegistry}.js`، شرط در `HookCondition.js`، rendering در `HookRenderer.js`، result/report در `HookResult.js` و اجرای runtime در `HookRunner.js` قرار گرفت.
- **Facade:** `agent/lib/hooks.js` و exportهای `runHooks`/`hookRegistry` در `agent.js` wrapperهای سازگار هستند؛ هیچ module جدیدی به `agent.js` وابستگی ندارد.
- **Execution:** HookRunner از executorهای عادی tool/delegation استفاده می‌کند؛ بنابراین policy/approval، telemetry، project context، dependency graph، cancellation و رویدادهای `hook:*` همان مسیر قبلی را حفظ می‌کنند.
- **Flag:** فاز ۲۲ `*_MODE` جدیدی اعلان نمی‌کند (تصمیم ۴۱). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۲۸. تغییرات additive فاز ۲۳ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **بدون تغییر قرارداد محصول:** تمام routeها، methodها، status codeها، شکل JSON، authentication/rate-limit، session replay، approval، settings، MCP و SSE بدون تغییر معنایی حفظ شده‌اند؛ استخراج backend ساختاری است.
- **Route inventory:** `web/server/RouteInventory.js` و فیلد additive `method_paths` در `test/fixtures/api-surface.json` مرجع 42 مسیر method × path هستند؛ پارامترهای dynamic با `:name` مستند می‌شوند.
- **Web modules:** `web/server/{WebServer,Router,RequestBody,Response,Middleware,SseHub}.js` و `controllers/`، `services/` و `serializers/` مرزهای جدیدند. `web/server.js` facade mode و `LegacyWebServer.js` compatibility implementation را نگه می‌دارند.
- **Modular rollout:** `WEB_SERVER_MODE` با پیش‌فرض `legacy` و مقدار `modular` از طریق settings schema خوانده می‌شود. در هر دو mode، `web.test.js` و APIهای project-scoped همان رفتار را دارند.
- **SSE:** client filtering و keep-alive در `SseHub` encapsulate شده و project authorization روی eventهای live و snapshot حفظ شده است.

## ۲۹. تغییرات additive فاز ۲۴ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **قالب frontend:** native browser ESM بدون build step انتخاب شد؛ `index.html` بعد از `modal.js`، `/app/main.js` را با `type="module"` بارگذاری می‌کند.
- **Domain modules:** `web/public/app/` شامل bootstrap، store/reducers، API، SSE، task، chat، execution، events، settings، MCP، history، plan، modal، markdown، direction، DOM، formatters و project/runtime/approval selectors است.
- **Compatibility:** `app.js` به‌عنوان renderer سازگار باقی مانده و از `app/main.js` import می‌شود؛ `/app.js` همچنان به‌عنوان asset موجود است تا embedها و تست‌های فعلی نشکنند. selector/idهای `index.html` و Modal lifecycle تغییر نکرده‌اند.
- **State/security:** store با domainهای جدا و reducerهای additive کار می‌کند؛ EventStream URL نسبی و `projectId` encode‌شده می‌سازد؛ API client هیچ endpoint absolute یا localhost ندارد؛ markdown با `textContent` و direction با تشخیص RTL امن می‌ماند.
- **Flag:** فاز ۲۴ flag جدیدی اعلان نمی‌کند (تصمیم ۴۳). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۳۰. تغییرات additive فاز ۲۵ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **Visualizer:** native ESM در `web/public/visualizer/main.js` فعال شد و `visualizer.js` compatibility renderer برای direct embed حفظ شد.
- **Graph domain:** `api-client`، `graph-store`، `graph-model`، `graph-renderer`، `layout-client`، `selection-state`، `node-details` و `visualizer-events` state و مسئولیت‌ها را از chat console جدا می‌کنند.
- **Project scope:** graph، neighborhood و impact URLها relative هستند و `projectId`، `seedId` و `symbol` را encode می‌کنند؛ state هر visualizer project-local است.
- **Layout/selection:** worker layout deterministic است و در نبود Worker یا خطای worker به layout grid deterministic fallback می‌کند؛ focus depth، resolved-only، node selection، drill-down و inspector metadata حفظ می‌شوند.
- **Security:** متن label/signature/connection با `textContent`/DOM API رندر می‌شود و خروجی inspector مسیر HTML خام ندارد؛ graph interactions و endpointهای موجود حذف یا rename نشده‌اند.
- **Flag:** فاز ۲۵ flag جدیدی اعلان نمی‌کند (تصمیم ۴۴). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۳۱. تغییرات additive فاز ۲۶ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **CLI:** `agent/cli/` شامل `ArgParser`، `CommandRegistry`، `OutputFormatter`، commandهای Help/Run/Serve/Interactive و facade `Cli` است؛ `bin/agent.js` wrapper سازگار باقی مانده است. تمام flagها و exit codeها حفظ شده‌اند.
- **Interactive:** `agent/interactive/` شامل `Repl`، `ReplCommands`، `InputReader`، `OutputRenderer` و `ApprovalPrompt` است؛ `bin/interactive.js` مسیر قدیمی را حفظ می‌کند. commandهای `/help`، `/clear`، `/history`، `/approve`، `/tools` و `/save` و ترتیب input/approval تغییر نکرده‌اند.
- **Output:** `--json` همچنان فقط action JSON معتبر روی stdout می‌دهد؛ progress، error و approval output روی stderr/stdout تاریخی باقی می‌مانند؛ error action شکل قبلی را حفظ می‌کند.
- **Migration safety:** parsing قبل از load کردن runtime انجام می‌شود؛ `--project`/`--migrate`، project root registry، session history و `backfill-eventstore.js` بدون تغییر معنایی حفظ شده‌اند.
- **Flag:** فاز ۲۶ flag جدیدی اعلان نمی‌کند (تصمیم ۴۵). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۳۲. تغییرات additive فاز ۲۷ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **Event modules:** تولید و correlation در `agent/events/EventBus.js` و `EventContext.js`، inventory در `EventTypes.js`، validation در `EventValidator.js`، projection در `EventProjector.js` و redaction در `EventRedactor.js` قرار گرفتند؛ `agent/lib/events.js` facade سازگار است.
- **Envelope:** فیلدهای `seq`، `type`، `at`، `run_id`، `turn_id`، `scope` و `iteration` حفظ شدند؛ `project_id` فقط به‌صورت additive روی scopeهای پروژه‌ای می‌آید؛ payload صریح بر context مقدم است.
- **Projection:** استریم پروژهٔ جاری eventهای همان پروژه را کامل، eventهای global را metadata aggregate و eventهای پروژهٔ دیگر را حذف می‌کند؛ replay از همان projector استفاده می‌کند.
- **Redaction:** event durable برای replay/نویسنده تغییر نمی‌کند؛ `redactForLog` secretها و source material را برای log/external surface mask می‌کند و `logObject` از آن استفاده می‌کند.
- **Observability:** metric/health consumer event bus باقی می‌ماند و business event تولید نمی‌کند؛ تفکیک سری‌های project/global و سلامت پروژه‌ها حفظ شده است.
- **Flag:** فاز ۲۷ flag جدیدی اعلان نمی‌کند (تصمیم ۴۶). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).

## ۳۳. تغییرات additive فاز ۲۸ (ثبت‌شده ۲۰۲۶-۰۸-۲۶)

- **Discussion boundary:** `DiscussionService` و `DiscussionContext` runtime caller، project identity، event attribution و lifecycle را inject می‌کنند؛ `DiscussionEngine`، `PersonaRunner`، `ObserverRunner`، `LoopDetector` و `TranscriptStore` بدون require چرخه‌ای به `agent.js` کار می‌کنند.
- **Transcript persistence:** `TranscriptRepository` با `JsonRepository`/AtomicFile سند کامل هر discussion را در `<project dataRoot>/discussion/<id>.json` ذخیره می‌کند؛ rounds، observer decisions، final report، status و خطا برای replay حفظ می‌شوند. synthetic/legacy به `.agent/discussion` map می‌شود و فایل‌های قدیمی حذف نمی‌شوند.
- **Project isolation:** `GET/POST /api/projects/:projectId/discussions` و `GET /api/projects/:projectId/discussions/:discussionId` فقط dataRoot همان project را می‌خوانند/می‌نویسند؛ project دیگر transcript را list یا replay نمی‌کند؛ permission chain فاز ۹ حفظ است.
- **Events/UI/CLI:** eventهای `discussion:*` project_id additive دارند؛ UI برای project فعال به route scoped می‌رود و `/api/discussion` legacy باقی است؛ CLI `--discussion --project` transcript را در context پروژه ذخیره می‌کند.
- **Security:** workspace/root از runtime/registry می‌آید؛ `workspace` و `workspace_root` از آرگومان tool برای identity پذیرفته نمی‌شوند؛ caller همچنان از `callAI` role-based runtime استفاده می‌کند.
- **Flag:** فاز ۲۸ flag جدیدی اعلان نمی‌کند (تصمیم ۴۷). پیش‌فرض schema عوض نمی‌شود (تصمیم ۳۲).


## ۳۴. تکمیل قراردادها و تفکیک Test Suite (فاز ۲۹)

فاز ۲۹ قراردادهای عمومی را از تست‌های domain جدا کرد؛ split تست‌ها نباید قرارداد محصول را تغییر دهد. suiteهای قبلی با همان assertions اجرا می‌شوند و contractهای جدید فقط شکاف‌های شناخته‌شده را قفل می‌کنند.

### Tool boundary

- منبع canonical schema، concat فایل‌های `agent/registry/tool-schemas/*.json` است؛ snapshot `agent/registry/tools.json` باید با آن برابر بماند.
- هر declaration از شکل `type: "function"`، نام پایدار و `parameters` یا `input_schema` تشکیل می‌شود.
- `ToolRegistryAdapter.parity()` باید `missing: []` و `extra: []` بدهد؛ هیچ implementation بدون declaration نباید model-facing شود.
- هویت پروژه (`projectId`/`project_id`/`project`/root) در args ابزار مجاز نیست و فقط از context معتبر می‌آید.

### API boundary

`test/fixtures/api-surface.json` مرجع مستقل method/path و response contracts است. فیلدهای موجود حذف نمی‌شوند؛ فیلدهای project و discussion additive هستند:

| contract | status | required keys |
|---|---:|---|
| `legacy_task` | 202 | `accepted` |
| `project_task` | 202 | `accepted`, `project_id` |
| `discussion_start` | 202 | `accepted`, `id`, `project_id` |
| `discussion_replay` | 200 | `project_id`, `discussion` |
| `error` | 400 | `error` |

`test/contracts/api.contract.test.js` هم‌خوانی fixture با `RouteInventory`، decode شدن پارامترهای dynamic فقط یک‌بار، status/content-type و serializerهای additive را بررسی می‌کند؛ تست‌های live در `test/web/` باقی می‌مانند.

### Persistence boundary

- JSON documentها با temp sibling و rename اتمیک نوشته می‌شوند؛ شکست rename فایل قبلی را تغییر نمی‌دهد.
- JSONLهای journal/eventstore append-only هستند؛ خط ناقص یا خراب در انتهای فایل read را fail نمی‌کند.
- `SchemaVersion`، `SafeIdentifier` و facadeهای session/eventstore/journal نام‌ها و مسیرهای تاریخی را حفظ می‌کنند.

### Discussion boundary

`DiscussionService` caller، context و event lifecycle را inject می‌کند. transcript با `project_id` و `dataRoot` پروژه قفل می‌شود؛ list/load پروژهٔ دیگر null/غیرقابل‌مشاهده است و workspace ارائه‌شده توسط model هویت محسوب نمی‌شود.

### Differential rule

در extractionهایی که mode legacy/modular دارند، خروجی قراردادی باید پس از حذف نویز با الگوی زیر برابر بماند و تفاوت‌های پروژه‌ای فقط additive باشند:

```js
assert.deepStrictEqual(normalize(modularOutput), normalize(legacyOutput));
```

شواهد اجرایی این قاعده در `test/prompt/builder.test.js`، `test/runs/run-context.test.js`، `test/runtime/engine.test.js` و تست‌های compatibility وب/CLI حفظ شده است.


## ۳۵. Rollout نهایی و حذف facadeها (فاز ۳۰)

پس از تثبیت برابری مسیرهای استخراج‌شده، مسیرهای compatibility دیگر بخشی از
runtime نیستند:

- importهای داخلی فقط به `agent/config`، `agent/context`، `agent/events`،
  `agent/hooks`، `agent/mcp`، `agent/persistence`، `agent/policy`،
  `agent/projects`، `agent/prompt`، `agent/runtime` و گروه‌های canonical
  `agent/tools` اشاره می‌کنند. `agent/lib/` حذف شده است.
- فایل‌های MCP و tool با نام‌های lowercase که فقط facade بودند حذف شده‌اند؛
  entrypointهای `McpConfig`، `McpConnection`، `McpManager`، `mcp/protocol/`
  و transportهای named مرجع هستند.
- Web server فقط از `web/server/WebServer.js` ساخته می‌شود و frontend فقط
  `web/public/app/main.js` و `web/public/visualizer/main.js` را bootstrap می‌کند.
  rendererهای canonical در `app/console.js` و `visualizer/renderer.js` هستند.
- شش rollout setting مرحله‌ای (`PROJECT_CONTEXT_MODE`، `RUN_CONTEXT_MODE`،
  `PROMPT_BUILDER_MODE`، `SEMANTIC_POOL_MODE`، `RUNTIME_ENGINE_MODE` و
  `WEB_SERVER_MODE`) از `SettingsSchema` حذف شده‌اند. نبود این settingها
  contract است؛ flagهای مستقل محصول مانند sandbox و response format حذف نشده‌اند.
- synthetic default همچنان برای خواندن/مهاجرت دادهٔ قبلی از `<workspace>/.agent`
  استفاده می‌کند؛ این data compatibility است، نه مسیر اجرایی دوم.

تست `test/contracts/rollout.contract.test.js` نبودن facadeها، canonical بودن
entrypointها، حذف flagها و نبودن require به مسیرهای قدیمی را بررسی می‌کند.
